function enter(pi) {
    //idk
}