function enter(pi) {
    pi.playerMessage(5, "Currently unavailable.");
}