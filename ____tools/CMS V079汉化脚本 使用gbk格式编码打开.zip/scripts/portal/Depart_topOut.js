function enter(pi) {
    pi.warp(103040300,0);
    pi.playPortalSE();
}