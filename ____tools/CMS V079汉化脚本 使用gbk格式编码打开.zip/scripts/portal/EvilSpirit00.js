﻿/*
	六手邪神PQ
**/

function enter(pi) {
    pi.openNpc(9250022);
    pi.dispose();
}
