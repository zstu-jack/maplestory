function enter(pi) {
    pi.showWZEffect("Effect/Direction3.img/ghostShip/chat");
	return true;
}