function enter(pi) {
    pi.warp(541020000,0);
}