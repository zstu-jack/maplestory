function enter(pi) {
    pi.warp(270050000,0);
}