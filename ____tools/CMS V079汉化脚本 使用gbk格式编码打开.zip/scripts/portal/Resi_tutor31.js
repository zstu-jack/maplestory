function enter(pi) {
    pi.openNpc(2159006);
	return true;
}