function enter(pi) {
    pi.warp(240080000,0);
    return true;
}