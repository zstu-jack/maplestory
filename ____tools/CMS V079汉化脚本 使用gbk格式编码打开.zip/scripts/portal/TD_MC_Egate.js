function enter(pi) {
	pi.playPortalSE();
	pi.warp(106021300, 0);
}