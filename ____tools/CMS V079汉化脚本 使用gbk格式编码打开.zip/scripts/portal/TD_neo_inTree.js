function enter(pi) {
    var qq = 3719;
    if (pi.isQuestActive(qq)) {
	pi.forceCompleteQuest(qq);
	pi.playerMessage("Quest complete");
    }
    qq = 3724;
    if (pi.isQuestActive(qq)) {
	pi.forceCompleteQuest(qq);
	pi.playerMessage("Quest complete");
    }
    qq = 3730;
    if (pi.isQuestActive(qq)) {
	pi.forceCompleteQuest(qq);
	pi.playerMessage("Quest complete");
    }
    qq = 3736;
    if (pi.isQuestActive(qq)) {
	pi.forceCompleteQuest(qq);
	pi.playerMessage("Quest complete");
    }
    qq = 3742;
    if (pi.isQuestActive(qq)) {
	pi.forceCompleteQuest(qq);
	pi.playerMessage("Quest complete");
    }
    qq = 3748;
    if (pi.isQuestActive(qq)) {
	pi.forceCompleteQuest(qq);
	pi.playerMessage("Quest complete");
    }
}