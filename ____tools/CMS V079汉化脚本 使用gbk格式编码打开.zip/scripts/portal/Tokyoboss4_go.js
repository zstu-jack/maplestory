function enter(pi) {
    pi.playPortalSE();
    pi.warp(802000610, 0);
    return true;
}