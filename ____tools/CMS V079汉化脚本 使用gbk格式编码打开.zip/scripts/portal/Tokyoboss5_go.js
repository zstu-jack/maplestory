function enter(pi) {
    pi.playPortalSE();
    pi.warp(802000110, 0);
    return true;
}