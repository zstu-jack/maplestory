/*
    Zakum Entrance
*/

function enter(pi) {
    pi.openNpc(2030013);
	return true;
}