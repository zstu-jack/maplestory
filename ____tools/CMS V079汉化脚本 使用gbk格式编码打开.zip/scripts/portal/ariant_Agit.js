function enter(pi) {
    pi.playPortalSE();
    pi.warp(260000201, "out00");
}