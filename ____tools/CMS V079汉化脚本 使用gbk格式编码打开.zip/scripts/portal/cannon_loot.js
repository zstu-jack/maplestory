function enter(pi) {
	if (pi.isQuestActive(2564)) {
		pi.ShowWZEffect("UI/tutorial.img/21");
		return true;
	}
	return false;
}