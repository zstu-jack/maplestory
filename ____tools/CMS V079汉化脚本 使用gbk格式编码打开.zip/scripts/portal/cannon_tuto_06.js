function enter(pi) {
	pi.setDirectionStatus(true);
	pi.lockUI2();
	pi.openNpc(3, 1096003);
	return true;
}