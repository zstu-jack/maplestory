function enter(pi) {
	pi.openNpc(8, 1096005);
	return true;
}