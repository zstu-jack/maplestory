function enter(pi) {
    pi.playPortalSE();
    pi.warp(925000000, 2);
}