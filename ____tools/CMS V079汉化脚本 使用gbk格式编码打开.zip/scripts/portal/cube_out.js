function enter(pi) {
		pi.warp(502029000,0);
}