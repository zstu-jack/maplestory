function enter(pi) {
    pi.warpParty(925100302);
}