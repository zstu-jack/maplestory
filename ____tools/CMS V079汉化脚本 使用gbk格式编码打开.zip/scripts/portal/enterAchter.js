function enter(pi) {
    	pi.warp(100000201, "out02");
	pi.playPortalSound();
	return true;
}