function enter(pi) {
	pi.playerMessage(5, "This map is currently blocked.");
	return false;
}