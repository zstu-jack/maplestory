function enter(pi) {
	pi.warp(310000004,0); //quest
}