﻿function enter(pi) {
    pi.playerMessage(5, "不可以用....");
}