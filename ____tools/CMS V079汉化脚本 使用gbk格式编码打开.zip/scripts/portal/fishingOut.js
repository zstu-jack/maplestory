function enter(pi) {
    pi.warp(910000000,0);
}