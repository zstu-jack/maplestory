function enter(pi) {
	pi.playerMessage(5, "很抱歉，轉蛋屋暫時不開放!");
	return false;
}