function enter(pi) {
	pi.openNpc(9000075);
	return true;
}