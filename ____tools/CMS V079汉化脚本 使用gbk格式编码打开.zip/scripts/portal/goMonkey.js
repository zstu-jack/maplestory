function enter(pi) {
	pi.openNpc(9000080);
	return true;
}