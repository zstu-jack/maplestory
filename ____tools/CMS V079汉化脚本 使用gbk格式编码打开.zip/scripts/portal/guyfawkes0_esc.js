﻿function enter(pi) {
    pi.playerMessage(5, "這個入口無法進入，詳細情況請找查理斯。");
}