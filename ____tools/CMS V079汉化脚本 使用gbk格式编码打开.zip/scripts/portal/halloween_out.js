function enter(pi) {
	pi.saveLocation("MULUNG_TC");
	pi.warp(910000000,0);
	return true;
}