function enter(pi) {
// do nothing,.
    pi.getPlayer().dropMessage(5, "Not available.");
}