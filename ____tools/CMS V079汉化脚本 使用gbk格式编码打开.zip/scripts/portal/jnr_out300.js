function enter(pi) {
	pi.warpParty(926110400,0, pi.getPlayer().getEventInstance().getPlayers());
}