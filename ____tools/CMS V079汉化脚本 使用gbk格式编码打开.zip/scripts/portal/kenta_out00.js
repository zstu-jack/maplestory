function enter(pi) {
    pi.warp(923040000,0);
}