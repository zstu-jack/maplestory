function enter(pi) {
	pi.playPortalSound();
	pi.warp(211060010, "west00");
	return true;
}