function enter(pi) {
    pi.warp(749040001, 0);
}