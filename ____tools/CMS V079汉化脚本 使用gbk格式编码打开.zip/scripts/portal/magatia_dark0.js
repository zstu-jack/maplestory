function enter(pi) {
    pi.warp(261020700,0);
    pi.playPortalSE();
}