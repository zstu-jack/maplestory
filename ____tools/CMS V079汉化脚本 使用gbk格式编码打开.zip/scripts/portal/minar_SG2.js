function enter(pi) {
    pi.playPortalSE();
    pi.warp(240011000,5);
}