function enter(pi) {
    pi.warp(108000700,0);
 //what does this even do
}