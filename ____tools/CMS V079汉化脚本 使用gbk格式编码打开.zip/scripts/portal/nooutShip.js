function enter(pi) {
    pi.playerMessage(5, "I shouldn't go this way.");
}