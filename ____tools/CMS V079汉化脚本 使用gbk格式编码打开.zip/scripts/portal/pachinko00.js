function enter(pi) {
	pi.playerMessage(5, "很抱歉，小鋼珠暫時不開放!");
	return false;
}