function enter(pi) {
    pi.warp(920010100,0);
}