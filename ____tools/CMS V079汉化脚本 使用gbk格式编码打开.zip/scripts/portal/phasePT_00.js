function enter(pi) {
    pi.playerMessage("Portal is not available.");
}