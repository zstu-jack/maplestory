function enter(pi) {
	pi.openNpc(2161005);
}