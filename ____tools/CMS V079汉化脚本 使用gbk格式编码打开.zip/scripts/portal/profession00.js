function enter(pi) {
	pi.inArdentmill();
}