function enter(pi) {
    pi.saveLocation("PVP");
    pi.playPortalSE();
    pi.warp(701000210, "out00");
	return true;
}
