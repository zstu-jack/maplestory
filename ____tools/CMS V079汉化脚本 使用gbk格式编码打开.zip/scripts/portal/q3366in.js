function enter(pi) {
    pi.warp(926130101,0);
    pi.playPortalSE();
}