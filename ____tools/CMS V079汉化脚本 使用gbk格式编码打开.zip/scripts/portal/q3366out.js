function enter(pi) {
    pi.warp(926130000,0);
}