function enter(pi) {
    pi.warp(926130103,0);
    pi.playPortalSE();
}