function enter(pi) {
	pi.playPortalSE();
	pi.warp(140030000, 1);
}