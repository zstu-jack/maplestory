function enter(pi) {
	pi.warpParty(926100400,0, pi.getPlayer().getEventInstance().getPlayers());
}