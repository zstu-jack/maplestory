function enter(pi) {
    //if (pi.isQuestActive(6141)) { //ninja ambush :D
	//pi.getMap().killAllMonsters(true);
	//pi.spawnMonster(9300088,6); //is it good idea to spawn directly here?
	//pi.playerMessage(5, "Dark Lord disciples have emerged.");
    //} else {
    	pi.playerMessage(5, "This portal is currently unavailable");
    //}
}