//Author: kevintjuh93

function enter(pi) {  
	pi.warp(pi.getPlayer().getSavedLocation("EVENT"));
	return true;
}