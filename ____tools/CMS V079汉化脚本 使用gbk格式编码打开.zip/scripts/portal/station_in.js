function enter(pi) {
    pi.openNpc(2012006);
}