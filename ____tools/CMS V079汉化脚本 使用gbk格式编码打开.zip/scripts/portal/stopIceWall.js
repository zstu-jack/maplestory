function enter(pi) {
    //nothing
}