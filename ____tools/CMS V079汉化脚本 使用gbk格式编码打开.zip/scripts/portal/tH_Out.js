function enter(pi) {
    pi.playPortalSE();
    pi.warp(100000000);
    return true;
}
