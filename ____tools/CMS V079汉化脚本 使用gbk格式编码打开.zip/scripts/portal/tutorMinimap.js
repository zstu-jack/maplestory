function enter(pi) {
	pi.updateQuest(20022, "1");
	pi.guideHint(1);
	pi.blockPortal();
	return true;
}