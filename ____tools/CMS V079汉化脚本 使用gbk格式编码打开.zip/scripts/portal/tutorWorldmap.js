function enter(pi) {
    pi.summonMsg(11);
}